# Changelog

## v38

- Separated target node SSH hostname (`TARGET_HOST`) from RAC SCAN (`TARGET_SCAN_HOST`).
- Added an early blocking error when a SCAN address is supplied as the SSH target.
- Updated generated TNS aliases to use target SCAN without using SCAN for operating-system access.

## v37

- Changed the toolkit execution user from `ops` to `opc`.
- Added automatic target provisioning order: `dbaascli`, `dbcli`, then DBCA.
- Added managed `dbaascli` placeholder creation instead of blocking it.
- Added native DBCA fallback when OCI lifecycle utilities are unavailable.

## v36

- Added explicit interactive and non-interactive execution for every individual process.
- Added `process`, `processes`, and `process-list` command aliases.
- Added foreground/background examples for single, range, selected, and production-step execution.

## v35

- Added target-only TDE tablespace encryption.
- Added online target encryption after switchover with a PRIMARY/READ WRITE role gate.
- Added offline target datafile encryption after standby build with Redo Apply stop/restart handling.
- Added selectable encryption mode, AES algorithm, and optional PDB container settings.
- Added phased build menu and clean screen redraw.

## v34 — GitHub Edition

- Consolidated native RMAN and Data Guard physical standby workflows.
- Added purpose-first GitHub README and publishing guide.
- Standardized ops/oracle execution model.
- Included interactive/CLI/background/task-range/restart operation.
- Added GitHub security, contribution, license and ignore files.
